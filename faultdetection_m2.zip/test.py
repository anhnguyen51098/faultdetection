import faultdetection_m2.extract_object_module as exobj


image_path = r"26-4.jpg"
exobj.extract_image(image_path)
