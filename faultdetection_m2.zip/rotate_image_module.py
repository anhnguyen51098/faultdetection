import numpy as np
import cv2
import math
from scipy import ndimage

#the rotate img function will rotate the image
#adapt with the horizontal line

def rotate_img(image_path):
    # read, crop 3 pixel each size to avoid border
    img = cv2.imread(image_path)
    size = img.shape
    img_crop = img[3:size[0] - 3, 3:size[1] - 3]
    img_save = img_crop.copy()


    # use houghline to detect line
    img_gray = cv2.cvtColor(img_crop, cv2.COLOR_BGR2GRAY)
    img_edges = cv2.Canny(img_gray, 100, 100, apertureSize=3)
    lines = cv2.HoughLinesP(img_edges, 1, math.pi / 180.0, 100, minLineLength=80, maxLineGap=5)

    # in case that HoughLinesP cannot detect
    # we reduce minimum length of detected line
    # to increase detection posibility
    if lines is None:
        lines = cv2.HoughLinesP(img_edges, 1, math.pi / 180.0, 100, minLineLength=40, maxLineGap=5)
        if lines is None:
            # change brightness of image to see line clearly
            img_crop = change_brightness(img_crop, value=50)
            img_gray = cv2.cvtColor(img_crop, cv2.COLOR_BGR2GRAY)
            img_edges = cv2.Canny(img_gray, 100, 100, apertureSize=3)
            lines = cv2.HoughLinesP(img_edges, 1, math.pi / 180.0, 100, minLineLength=80, maxLineGap=5)

    angles = []
    for [[x1, y1, x2, y2]] in lines:
        cv2.line(img_crop, (x1, y1), (x2, y2), (255, 0, 0), 3)
        angle = math.degrees(math.atan2(y2 - y1, x2 - x1))
        angles.append(angle)

    # print angle of image
    median_angle = np.median(angles)
    print(f"Angle: {median_angle:.04f}")

    if median_angle < 0:
        img_rotated = ndimage.rotate(img_save, median_angle, cval=256)
    else:
        img_rotated = ndimage.rotate(img_save, median_angle + 180, cval=256)

    #cv2.imshow('Rotation', img_rotated)
    #key = cv2.waitKey(0)
    cv2.imwrite('rotated_obj.jpg', img_rotated)

    return img_rotated


def change_brightness(img, value=30):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    v = cv2.add(v, value)
    v[v > 255] = 255
    v[v < 0] = 0
    final_hsv = cv2.merge((h, s, v))
    img = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2BGR)
    return img
